#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>  
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>
#include <math.h>
#include <dirent.h>
#include <sys/types.h>
#include <signal.h>
#include <stdbool.h>
#include <errno.h>

#define BUF_S 124
#define M_SIZE 20
#define M_SIZE2 10
#define TEXT "pid.txt"
 
int state = 1,serverPid,rPid,cPid;
char clientFifo[24];
char mainFifo[24];

typedef struct MatrisInfo{

    float matris[20][20];
    int matrisSize;

}Matris;

void sighandler(int);
void catchSignal(int);
void printMatris(float mat[][M_SIZE],int size);
void cofactor(float num[][M_SIZE],float inverse[][M_SIZE2],float f);
void transpose(float num[][M_SIZE],float fac[][M_SIZE],float inverse[][M_SIZE2],float r);
float determinant(float a[][M_SIZE],float k);
bool shiftedInverseMatrix(float originalMat[][M_SIZE],float siftedMat[][M_SIZE],int size);
double getTime(struct timeval *tstart, struct timeval *tend);

int main(int argc, char* argv[])
{
    if(argc != 2)
    {
        fprintf(stderr, "eksik arguman\nusage : ./seeWhat mainpipeNamed" );
        return 0;
    }  
    
    
    char strMainMsg[BUF_S];   
    char strMsgToResult[BUF_S];
    char tempPid[24];   
    char tempPid2[24]; 
    char tempRes1[24];
    char fifo[24] = "showResultF";
    char logName[24];
    char temp[24];
    char strTime[24];

    int i,j;   
    int fdMain;
    int fdClient; 
    int fd;
    int pids;
    int ccPid;

    float result1;
    float det1;
    float det2;
    double time0;
    pid_t pid;    
    
    ssize_t r_byte;
    ssize_t w_byte;
     
    Matris matrisInfo;  

    struct timeval tend;
    struct timeval tstart;


    signal(SIGINT, sighandler); 
    signal(SIGTERM, catchSignal);  
   
    strcpy(mainFifo,argv[1]);   
  
    memset(strMainMsg,'\0',BUF_S); 
    memset(strMsgToResult,'\0',BUF_S); 

    FILE *inp;

    inp=fopen("file.txt","r");
    fscanf(inp,"%d", &pids);
    fclose(inp);
    if (kill(pids, SIGUSR2) != 0)
        fprintf(stderr, "Failed to send signal %d to %d\n", SIGUSR2,pids);

    cPid =getpid();
    FILE *fOut;
    fOut=fopen(TEXT,"ab+");
    fprintf(fOut,"%d\n",cPid);        
    

   

    if ((fd = open(fifo, O_WRONLY)) <0) 
    {
        perror("failed to open log fifo for writing");
        exit(1); 
    }    
    
    sleep(1);

    sprintf(tempPid,"%d",getpid());   
    strcat(strMainMsg,tempPid);    
    strcat(strMainMsg,"~");
    sprintf(tempPid2,"%d",rPid);
    strcat(strMainMsg,tempPid2);
    strcat(strMainMsg,"~");

    if((fdMain = open(mainFifo, O_WRONLY))==-1)
    {
        perror("failed to open mainFIFO\n");
        return 1;
    } 

   
    w_byte=write(fdMain, strMainMsg, strlen(strMainMsg));
    if(w_byte <0)
        fprintf(stderr, "Nothing was written to mainFIFO by client\n" );
    //close(fdMain);  
    // sleep(1);
    strcpy(clientFifo,tempPid);
    strcat(clientFifo,"_f");
   
    if(mkfifo(clientFifo, 0666) == -1)
    {
        perror("failed to creat clientFifo\n");
        return 1;
    }

    if((fdClient = open(clientFifo, O_RDONLY))==-1){
        perror("failed to open clientFifo\n");
        return 1;
    }

   
    r_byte=read(fdClient, &serverPid, sizeof(int));
    if(r_byte <0)
        fprintf(stderr, "Nothing was read to client FIFO\n" ); 

    fprintf(stderr," My pid is > %d \n",getpid());
    fprintf(stderr," My child pid in server > %d \n",serverPid);
   
    fprintf(stderr," ------------------------------- \n");
    fprintf(fOut, "%d\n", serverPid);
    fclose(fOut);

	while(state)
	{   	
        if (kill(serverPid, SIGUSR1) != 0)
            fprintf(stderr, "Failed to send signal %d to %d\n", SIGUSR1, serverPid);
        fprintf(stderr, "signal sending...\n" );
		r_byte = read(fdClient, &matrisInfo,sizeof(Matris));
        if(r_byte <0)
            fprintf(stderr, "Nothing was read to clientFIFO by client\n" );		
        
	    fprintf(stderr,"--------------------\n");
        //fprintf(stderr, "Original Matrix ...\n" );		
       // printMatris(matrisInfo.matris,matrisInfo.matrisSize);

        if((pid = fork())< 0)
        {
            perror("Failed to create the fork");
            return 1;
        }     
        if(pid==0)
        {   
           // ccPid=getpid();
            strcpy(logName,"log/");
            sprintf(temp,"%d",getpid());   
            strcat(temp,"_log");
            strcat(logName,temp);

            FILE *fLog;
            fLog=fopen(logName,"a");
            float shiftedMat[M_SIZE][M_SIZE];
            //fprintf(stderr, "shifted Inverse Matrix ...\n" );
            gettimeofday(&tstart,NULL);

            bool check = shiftedInverseMatrix(matrisInfo.matris,shiftedMat,matrisInfo.matrisSize);
          //  if(!check)
          //      fprintf(stderr, "det yok\n");
          //  else{
                //printMatris(shiftedMat,matrisInfo.matrisSize);
                det1=determinant(shiftedMat,matrisInfo.matrisSize);
                det2=determinant(matrisInfo.matris,matrisInfo.matrisSize);
                result1 = det2-det1;
                gettimeofday(&tend,NULL);
                
                time0=getTime(&tstart,&tend);
            
                fprintf(stderr, "Original Matrix det >> %.2f\n",det2);
                fprintf(stderr, "Shifted Inverse Matrix det >> %f\n",det1);
                fprintf(stderr, "Result1 >> %.2f\n",result1);
                fprintf(stderr, "Result1 elapse time >> %f milliseconds\n",time0);

                fprintf(fLog, "--------------------\n");
                fprintf(fLog, "Original Matrix\n");
                for(i=0;i<matrisInfo.matrisSize;i++){
                    for(j=0;j<matrisInfo.matrisSize;j++)
                        fprintf(fLog, "%.2f ",matrisInfo.matris[i][j]);
                    fprintf(fLog, "\n");
                }

                fprintf(fLog, "--------------------\n");
                fprintf(fLog, "Shifted Inverse Matrix\n");
                for(i=0;i<matrisInfo.matrisSize;i++){
                    for(j=0;j<matrisInfo.matrisSize;j++)
                        fprintf(fLog, "%.2f ", shiftedMat[i][j]);
                    fprintf(fLog, "\n");
                }
                fclose(fLog);
                

                strcpy(strMsgToResult,tempPid);
                strcat(strMsgToResult," -- ");
                sprintf(tempRes1,"%.2f",result1);
                strcat(strMsgToResult,tempRes1);
                strcat(strMsgToResult," -- ");
                sprintf(strTime,"%f",time0);
                strcat(strMsgToResult,strTime);

                w_byte=write(fd,strMsgToResult, strlen(strMsgToResult));
                if(w_byte <0)
                    fprintf(stderr, "Nothing was written to mainFIFO by client\n" );

              
               /* fprintf(fLog, "Client Pid >> %d\n",cPid );
                fprintf(fLog, "Result1    >> %f\n",result1);*/
                sleep(1);
           // }
           
            exit(0);
        }else{
            while(wait(NULL)>0);
            /*if (kill(serverPid, SIGUSR1) != 0)
            fprintf(stderr, "Failed to send signal %d to %d\n", SIGUSR1, serverPid);*/
       }
        
        fprintf(stderr,"---------------------\n");   
           

    }   

   // fprintf(fLog," --------------------------------------\n\n");        
    fprintf(stderr," -Server process is death > %d \n",serverPid);
    fprintf(stderr," -I am death > %d \n",getpid());
    
   /* fprintf(fLog," CTRL + C signal catched \n");
    fprintf(fLog," -Server process is death > %d \n",serverPid);
    fprintf(fLog," -I am death > %d \n",getpid());
*/
    close(fdClient);  
    unlink(clientFifo);
   // fclose(fLog);
    return 0;   
}    

double getTime(struct timeval *tstart, struct timeval *tend){
      double fark;
      /* make calculations  */
      fark = (tend->tv_sec - tstart->tv_sec)*1000.0+
                (tend->tv_usec - tstart->tv_usec)/1000.0;
     // fprintf(stderr, "fark :%f\n",fark );
      return (fark );
}
void sighandler(int signum) 
{       
    while(wait(NULL) > 0); 

    fprintf(stderr," CTRL + C signal catched - %d \n",getpid());

    int pid;
    if(cPid == getpid()){
        FILE *fOut;
        fOut=fopen(TEXT,"r");
        
        while(fscanf(fOut,"%d",&pid) != EOF)
        {        
            if(pid != cPid)
                kill(pid,SIGTERM);
         
        }
        fclose(fOut);
         state=0;

        if(cPid==getpid())
        {
          kill(serverPid,SIGTERM);
          unlink(clientFifo);
          raise(SIGKILL);        
        }
    }else{
        fprintf(stderr, "I am a death child who is compute result1 ...\n" );
        raise(SIGKILL);
    }
   
}
void catchSignal(int signum) 
{       
	while(wait(NULL) > 0); 	
	state=0;
}




void printMatris(float mat[][M_SIZE],int size){
    int i,j;
    for(i=0;i<size;i++){
        for(j=0;j<size;j++)
            fprintf(stderr, "%.2f ", mat[i][j]);
        fprintf(stderr, "\n");
    }
}
bool shiftedInverseMatrix(float originalMat[][M_SIZE],float shiftedMat[][M_SIZE],int size){
    float tempMat[M_SIZE][M_SIZE];
    float tmpInverse1[M_SIZE2][M_SIZE2];
    float tmpInverse2[M_SIZE2][M_SIZE2];
    float tmpInverse3[M_SIZE2][M_SIZE2];
    float tmpInverse4[M_SIZE2][M_SIZE2];

    float det;

    int i,j;
    if(size == 2){
        //fprintf(stderr, "size 1\n" );
        for(i=0;i<size;++i)
            for(j=0;j<size;++j)
                shiftedMat[i][j] = originalMat[i][j];
                return true;
    }
    for(i=0;i<size/2;i++)
        for(j=0;j<size/2;j++)
            tempMat[i][j] = originalMat[i][j];
   // fprintf(stderr, "temp-1\n" );
    //printMatris(tempMat,size/2); 

    det=determinant(tempMat,size/2);  
    if(det == 0)
        return false;
    else
        cofactor(tempMat,tmpInverse1,size/2);

    for(i=0;i<size/2;++i)
        for(j=0;j<size/2;++j)
            shiftedMat[i][j] = tmpInverse1[i][j];
//////////////////////////////////////////////////////////////////
    int k=0,l=0;
    for(i=size/2;i<size;++i,k++)
        for(j=0,l=0;j<size/2;++j,l++)
            tempMat[k][l] = originalMat[i][j];

   // fprintf(stderr, "temp-2\n" );
   // printMatris(tempMat,size/2);

    det=determinant(tempMat,size/2);  
    if(det == 0)
         return false;
    else
        cofactor(tempMat,tmpInverse2,size/2);

    for(i=size/2,k=0;i<size;++i,k++)
        for(j=0,l=0;j<size/2;++j,l++)
            shiftedMat[i][j] = tmpInverse2[k][l];
/////////////////////////////////////////////////////////////////
    for(i=0,k=0;i<size/2;++i,k++)
        for(j=size/2,l=0;j<size;++j,l++)
            tempMat[k][l] = originalMat[i][j];
    
   // fprintf(stderr, "temp-3\n" );
  // printMatris(tempMat,size/2);

    
    det=determinant(tempMat,size/2);     
    if(det == 0)
         return false;
    else
        cofactor(tempMat,tmpInverse3,size/2);

    for(i=0,k=0;i<size/2;++i,k++)
        for(j=size/2,l=0;j<size;++j,l++)
            shiftedMat[i][j] = tmpInverse3[k][l]; 

////////////////////////////////////////////////////////////////////

    for(i=size/2,k=0;i<size;++i,k++)
        for(j=size/2,l=0;j<size;++j,l++)
            tempMat[k][l] = originalMat[i][j];

    //fprintf(stderr, "temp-4\n" );    
   // printMatris(tempMat,size/2);

    det=determinant(tempMat,size/2); 
    if(det == 0)
        return false;
    else
        cofactor(tempMat,tmpInverse4,size/2);

    for(i=size/2,k=0;i<size;++i,k++)
        for(j=size/2,l=0;j<size;++j,l++)
            shiftedMat[i][j] = tmpInverse4[k][l];  
/*
        fprintf(stderr, "inverse-1\n" );
        printMatris(tmpInverse1,size/2);
        fprintf(stderr, "inverse-2\n" );
        printMatris(tmpInverse2,size/2);
        fprintf(stderr, "inverse-3\n" );
        printMatris(tmpInverse3,size/2);
        fprintf(stderr, "inverse-4\n" );
        printMatris(tmpInverse4,size/2);
*/
        return true;
}
  
/*
*Internetten alındı
*/
float determinant(float a[][M_SIZE],float k)
{
  float s=1,det=0,b[M_SIZE][M_SIZE];
  int i,j,m,n,c;
  if (k==1)
    {
     return (a[0][0]);
    }
  else
    {
     det=0;
     for (c=0;c<k;c++)
       {
        m=0;
        n=0;
        for (i=0;i<k;i++)
          {
            for (j=0;j<k;j++)
              {
                b[i][j]=0;
                if (i != 0 && j != c)
                 {
                   b[m][n]=a[i][j];
                   if (n<(k-2))
                    n++;
                   else
                    {
                     n=0;
                     m++;
                     }
                   }
               }
             }
          det=det + s * (a[0][c] * determinant(b,k-1));
          s=-1 * s;
          }
    }

    return (det);
}

void cofactor(float num[][M_SIZE],float inverse[][M_SIZE2],float f)
{
 float b[M_SIZE][M_SIZE],fac[M_SIZE][M_SIZE];
 int p,q,m,n,i,j;
 for (q=0;q<f;q++)
 {
   for (p=0;p<f;p++)
    {
     m=0;
     n=0;
     for (i=0;i<f;i++)
     {
       for (j=0;j<f;j++)
        {
          if (i != q && j != p)
          {
            b[m][n]=num[i][j];
            if (n<(f-2))
             n++;
            else
             {
               n=0;
               m++;
               }
            }
        }
      }
      fac[q][p]=pow(-1,q + p) * determinant(b,f-1);
    }
  }
  transpose(num,fac,inverse,f);
}
/*Finding transpose of matrix*/  
void transpose(float num[][M_SIZE],float fac[][M_SIZE],float inverse[][M_SIZE2],float r)
{
  int i,j;
  float b[M_SIZE][M_SIZE],d;

  for (i=0;i<r;i++)
    {
     for (j=0;j<r;j++)
       {
         b[i][j]=fac[j][i];
        }
    }
  d=determinant(num,r);
  for (i=0;i<r;i++)
    {
     for (j=0;j<r;j++)
       {
        inverse[i][j]=b[i][j] / d;
        }
    }
  /* printf("\n\n\nThe inverse of matrix is : \n");

   for (i=0;i<r;i++)
    {
     for (j=0;j<r;j++)
       {
         printf("\t%f",inverse[i][j]);
        }
    printf("\n");
     }*/
}
