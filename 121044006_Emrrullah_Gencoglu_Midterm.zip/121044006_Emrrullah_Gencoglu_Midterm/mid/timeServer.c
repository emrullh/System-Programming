#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>  
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>
#include <math.h>
#include <dirent.h>
#include <sys/types.h>
#include <signal.h>
#include <errno.h>
#include <assert.h>
#include <stdbool.h>
#include <sys/time.h>

#define BUFFER_SIZE 256
#define BUF_S 124
#define M_SIZE 20
#define TEXT "pid.txt"

volatile sig_atomic_t sig_flag = false;

int state = 1, state2=1;
int sPid, cPid,rPid;
int flag1=1;
int flag2=0;
char mainFifo[24];

typedef struct MatrisInfo{

    float matris[20][20];
    int matrisSize;

}Matris;
static void sigusr1(int signo)
{
   
    flag1=1;
    //state2=1;
    //fprintf(stderr, "signal1 catched\n" );
}
static void sigusr2(int signo)
{
    
   
    flag2=1;
   //fprintf(stderr, "signal2 catched\n" );
}
void handle_alarm( int sig ) {
    //signal(SIGALRM,SIG_IGN);
    sig_flag = true;
    //flag=1;
   // fprintf(stderr, "alarm\n" );
   //signal(SIGALRM,handle_alarm);
}
void sighandler(int);
void catchSignal(int);

float getTime(struct timeval *tstart, struct timeval *tend);
void createMatris(int matrisSize,Matris *info);
float determinant(float a[][M_SIZE],float k);
void printMatris(float mat[][M_SIZE],int size);

/*kitaptan alındı*/
static int setupinterrupt(void){
    struct sigaction act3;
    act3.sa_handler = handle_alarm;
    act3.sa_flags=0;
    return (sigemptyset(&act3.sa_mask) || sigaction(SIGPROF,&act3,NULL));
}
static int setupitimer(int time){
    struct itimerval value;
    value.it_interval.tv_sec=0;
    value.it_interval.tv_usec=1000*time;
    value.it_value= value.it_interval;
    return (setitimer(ITIMER_PROF,&value,NULL));
}

int main(int argc, char* argv[])
{
    if(argc != 4)
    {
    	fprintf(stderr, "eksik arguman\nusage :./timeServer <ticks in milisecond> , < n (matris)> ,mainpipeNamed" );
    	return 0;
    }

    FILE *fLog;
    fLog=fopen("log/timeServer.log","a");

	struct timeval tend;
	struct timeval tstart;

    struct sigaction act;
    sigset_t block_mask;
    sigfillset(&block_mask);
    act.sa_handler = sigusr1;
    act.sa_mask = block_mask;
    act.sa_flags = 0;

    struct sigaction act2;
    sigset_t block_mask2;
    sigfillset(&block_mask2);
    act2.sa_handler = sigusr2;
    act2.sa_mask = block_mask2;
    act2.sa_flags = 0;

    char clientFifo[24]; 
    char strMainMsg[BUF_S]; 
    char strMainMsg2[BUF_S];
    char temp[24];
    char *tempPid;
    char *tempPid2;

	int fdMain;
    int fdClient;
    int sChildPid;
	int i,j;
    int signalTime;
    int matrisSize;
   
    float time0;
    double time1;

    pid_t pid;

    ssize_t w_byte;
    ssize_t r_byte;

    Matris *info;

    sPid = getpid();

    FILE *inp;

    inp=fopen("file.txt","w");
    fprintf(inp,"%d\n",sPid);
    fclose(inp);
    
    FILE *fOut;
    fOut=fopen(TEXT,"ab+");
    fprintf(fOut,"%d\n",sPid);        
    fclose(fOut);


    signal(SIGINT, sighandler); 
    signal(SIGTERM, catchSignal);

    signal( SIGALRM, handle_alarm ); // Install handler first,    
    sigaction(SIGUSR1, &act, NULL);
    sigaction(SIGUSR2, &act2, NULL) ;

    //alarm(1);
    
    signalTime = atoi(argv[1]);
    matrisSize = 2 * atoi(argv[2]);
    sscanf(argv[3],"%s",mainFifo); //read arguman
    
    if(setupinterrupt() == -1)
        return 1;
    if(setupitimer(signalTime) == -1)
        return 1;
   // ualarm(signalTime,signalTime);

    memset(strMainMsg2,'\0',BUF_S);
    memset(strMainMsg,'\0',BUF_S);
    fprintf(stderr," *****************************************\n");
    fprintf(stderr," -My id is %d. wait for connect Client.. \n",sPid);
      
    
    
    while(state2)
    {       
        if (sig_flag ) 
        {
            if(flag2)
            {

                if(mkfifo(mainFifo, 0666)==-1)
                {
                    perror("failed to create a mainFIFO");
             		return 1; 
                }
                if((fdMain = open(mainFifo, O_RDONLY))==-1)
                {
              	    perror(" failed to open a mainFIFO");
             		return 1; 
                }  
                 
                r_byte = read(fdMain, strMainMsg,BUF_S*sizeof(char));       
                if(r_byte <0)
                    fprintf(stderr, "Nothing was read to client FIFO\n" ); 	
                    
                
                if((pid = fork())< 0)
                {
                    perror("Failed to create the fork");
                    return 1;
                }
                //sleep(1);       
                if(pid == 0)
                {		
                    sChildPid = getpid();      	   
              	
                    tempPid = strtok(strMainMsg,"~");
                    tempPid2 = strtok(NULL,"~");
                
                    cPid = atoi(tempPid);
                    rPid = atoi(tempPid2);
                    fprintf(stderr," Connected... \n-Client id ->%d ----- Result id ->%d ---- Client start time ->%f \n",cPid,rPid,time0);
                    //fprintf(fLog," Connected... \nClient id ->%d ---- Client start time ->%f \n",cPid,time0);        
                    
                    strcpy(clientFifo,tempPid);                         
                    strcat(clientFifo,"_f");
        	       
        	        
                    if((fdClient = open(clientFifo, O_WRONLY))==-1)
                    {
                        perror(" failed to open a fa");
                        return 1; 
                    }      
                   
                    w_byte = write(fdClient, &sChildPid, sizeof(int));
        	        if(w_byte <0)
                        fprintf(stderr, "Nothing was written to clientFIFO by server\n" );
                    
        		    while(state)
        			{   
                        
                        if(flag1)
                        {	

                            gettimeofday(&tstart,NULL);

                            info=(Matris *)malloc(sizeof(Matris));

                            createMatris(matrisSize,info);

                            info->matrisSize=matrisSize;

                            printMatris(info->matris,info->matrisSize);
                            

                            gettimeofday(&tend,NULL);
                            time0=getTime(&tstart,&tend); //milisaniye cinsinden
                            fprintf(stderr, "matrix created in %f milliseconds\n",time0 );
                           
                            
                            float det = determinant(info->matris,info->matrisSize);
                            fprintf(fLog, "-- Client Id => %d -- Matrix Created in %f milliseconds -- Matrix determinant =>%.2f\n",cPid,time0,det );
                            fprintf(stderr, "Matrix determinant >> %f\n",det );
                           
                            if(det != 0)
                            {    
                                printMatris(info->matris,info->matrisSize);          	   
                                w_byte=write(fdClient,info,sizeof(struct MatrisInfo));
                                if(w_byte <0)
                                    fprintf(stderr, "Nothing was written to clientFIFO by server\n" );
                                flag1=0;
            	            }else{
                                fprintf(stderr, "determinat gitmedi\n" );
                                printMatris(info->matris,info->matrisSize);
                                flag1=1;
                            }
            	            fprintf(stderr," --------------------------------------\n");
                            
            	          
                          free(info);
                         
                        }	
                       // fprintf(stderr, "aaa\n" );
                       // sleep(1);

                    }
              
                    fprintf(stderr," -Client is death > %d \n",cPid);
                    fprintf(stderr," -So,child dead > %d \n",getpid());

                    fprintf(fLog," -Client is death > %d \n",cPid);
                    fprintf(fLog," -So, child dead > %d \n",getpid()); 
                    fprintf(fLog," --------------------------------------\n");               
                    exit(0);                            
                }
                flag2=0;
            }
            sig_flag = false;
            //alarm(1);
            //ualarm(signalTime,signalTime);
            close(fdMain);
            unlink(mainFifo);    
        }

    }
          
   

    fclose(fLog);
   
    return 0;
}


void sighandler(int signum) 
{       
    while(wait(NULL) > 0); 

    fprintf(stderr," CTRL + C signal catched - %d \n",getpid());

    int pid;

    FILE *fOut;
    fOut=fopen(TEXT,"r");

    while(fscanf(fOut,"%d",&pid) != EOF)
    {
        //fprintf(stderr, "bjsdjvbsd %d\n",pid );
        if(pid != getpid())
            kill(pid,SIGTERM);
    }
    fclose(fOut);
   
    if(sPid==getpid())
    {
      unlink(mainFifo);
       remove(TEXT);
      raise(SIGKILL);        
    }
    state=0;
}

void catchSignal(int signum) 
{       
while(wait(NULL) > 0); 
 
    //fprintf(stderr," SIGTERM signal catched - %d \n",getpid());
    state2=0;
    state=0;
    unlink(mainFifo);
    remove(TEXT);
    remove("file.txt");
    raise(SIGKILL);  

}

float getTime(struct timeval *tstart, struct timeval *tend){
      float fark;
      /* make calculations	*/
      fark = (tend->tv_sec - tstart->tv_sec)*1000.0f+
                (tend->tv_usec - tstart->tv_usec)/1000.0f;
     // fprintf(stderr, "fark :%f\n",fark );
      return (fark );
}
void createMatris(int matrisSize,Matris *info){
    
    int i=0;
    int j=0;
    for(i=0;i<matrisSize;++i)
        for(j=0;j<matrisSize;++j)
            info->matris[i][j]=(rand()%10);

         //fprintf(stderr,"--------------------\n");
       
}
void printMatris(float mat[][M_SIZE],int size){
    int i,j;
    for(i=0;i<size;i++){
        for(j=0;j<size;j++)
            fprintf(stderr, "%.2f ", mat[i][j]);
        fprintf(stderr, "\n");
    }
}
float determinant(float a[][M_SIZE],float k)
{
    
    float s=1,det=0,b[M_SIZE][M_SIZE];
    int i,j,m,n,c;
    if (k==1)
    {
        return (a[0][0]);
    }
    else
    {
        det=0;
        for (c=0;c<k;c++)
        {
            m=0;
            n=0;
            for (i=0;i<k;i++)
            {
                for (j=0;j<k;j++)
                {
                    b[i][j]=0;
                    if (i != 0 && j != c)
                    {
                        b[m][n]=a[i][j];
                        if (n<(k-2))
                            n++;
                        else
                        {
                            n=0;
                            m++;
                        }
                   }
               }
             }
          det=det + s * (a[0][c] * determinant(b,k-1));
          s=-1 * s;
          }
    }

    return (det);
}


