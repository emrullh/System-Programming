#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>  
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>
#include <signal.h>

#define BUF_S 124
#define M_SIZE 20
#define M_SIZE2 10
#define TEXT "pid.txt"
 
int state = 1,serverPid,rPid;
char fifo[24] = "showResultF";

void sighandler(int);
void catchSignal(int);

int main(int argc, char* argv[])
{
   

    FILE *fLog;
    fLog=fopen("showResult.log","a");

    
    
    char strMainMsg[BUF_S];      
   
    int fd,fdMain; 

     signal(SIGINT, sighandler); 
    signal(SIGTERM, catchSignal); 
    ssize_t r_byte;
    ssize_t w_byte;

    memset(strMainMsg,'\0',BUF_S);

    rPid=getpid();

    FILE *fOut;
    fOut=fopen(TEXT,"ab+");
    fprintf(fOut,"%d\n",rPid);        
    fclose(fOut);

    if(mkfifo(fifo, 0666) == -1)
    {
        perror("failed to creat clientFifo\n");
        return 1;
    }

    if((fd = open(fifo, O_RDONLY))==-1){
            perror("failed to open clientFifo\n");
            return 1;
    }  
    
        
    fprintf(stderr," ------------------------------- \n");
  
    
	while(state)
	{             
		r_byte = read(fd, strMainMsg,BUF_S);
        if(r_byte <0)
            fprintf(stderr, "Nothing was read to clientFIFO by client\n" );		         
        fprintf(stderr, "%s\n",strMainMsg );
        fprintf(fLog, "%s\n",strMainMsg );
        memset(strMainMsg,'\0',BUF_S);
    }   

    fprintf(stderr, "CTRL+C signal catched\n" );
    fprintf(fLog, "CTRL+C signal catched\n" );
    close(fd);  
    unlink(fifo);
    fclose(fLog);
    return 0;   
}    
void catchSignal(int signum) 
{       
    while(wait(NULL) > 0); 
    //fprintf(stderr," SIGTERM signal catched - %d \n",getpid());
    state=0;
}
void sighandler(int signum) 
{       
    while(wait(NULL) > 0); 

    fprintf(stderr," CTRL + C signal catched - %d \n",getpid());

    int pid;

    FILE *fOut;
    fOut=fopen(TEXT,"r");
    
    while(fscanf(fOut,"%d",&pid) != EOF)
    {
        //fprintf(stderr, "pid .. %d\n",pid );
        if(pid != getpid())
            kill(pid,SIGTERM);
    }
    fclose(fOut);
    
    if(rPid==getpid())
    {
      //kill(serverPid,SIGTERM);
      unlink(fifo);
      //remove("result.txt");
      raise(SIGKILL);        
    }
    state=0;
}